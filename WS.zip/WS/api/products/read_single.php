<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/product.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare product object
$product = new Product($db);

// set ID property of product to be edited
$product->id = $_GET['product_id'];
//$xd = $_GET['xd'];

// read the details of product to be edited
$stmt = $product->read_single();

if($stmt->rowCount() > 0){
    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    // create array
    $product_arr=array(
        "category_id" => $row['category_id'],
        "category_name" => $row['category_name'],
        "category_image" => $row['category_image'],
        "subcategory_name" => $row['subcategory_name'],
        "subcategory_image" => $row['subcategory_image'],
        "product_id" => $row['product_id'],
        "product_name" => $row['product_name'],
        "product_slug" => $row['product_slug'],
        "product_description" => $row['product_description'],
        "product_price" => $row['product_price'],
        "product_quantity" => $row['product_quantity'],
        "product_status" => $row['product_status'],
        "brand_name" => $row['brand_name'],
    );
}
// make it json format
print_r(json_encode($product_arr));
//print($xd);
?>