<?php
include_once '../config/database.php';
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);

$user->id = isset($_GET['id']) ? $_GET['id'] : die();

$stmt = $user->read_single();

if($stmt->rowCount() > 0){
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $user_arr=array(
        "id" => $row['id'],
        "name" => $row['name'],
        "last_name" => $row['last_name'],
        "email" => $row['email'],
        "password" => $row['password']
    );
}

print_r(json_encode($user_arr));
?>