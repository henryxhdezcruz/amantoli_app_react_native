<?php
include_once '../config/database.php';
include_once '../objects/user.php';
 
$database = new Database();
$db = $database->getConnection();
 
$user = new User($db);

$user->email = $_GET['email'];
$user->password = $_GET['password'];

$stmt = $user->login();

if($stmt->rowCount() > 0){
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    $user_arr=array(
        "id" => $row['id'],
        "name" => $row['name'],
        "email" => $row['email'],
        "password" => $row['password'],
        "email_verified_at" => $row['email_verified_at'],
    );
}
print_r(json_encode($user_arr));
?>