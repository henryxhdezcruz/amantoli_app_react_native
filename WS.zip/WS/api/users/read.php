<?php
// include database and object files
include_once '../config/database.php';
include_once '../objects/user.php';
 
// get database connection
$database = new Database();
$db = $database->getConnection();
 
// prepare user object
$user = new User($db);
 
// query user
$stmt = $user->read();
$num = $stmt->rowCount();
// check if more than 0 record found
if($num>0){
 
    // users array
    $users_arr=array();
    $users_arr["users"]=array();
 
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        extract($row);
        $user_item=array(
            "id" => $id,
            "name" => $name,
            "email" => $email,
            "password" => $password
        );
        array_push($users_arr["users"], $user_item);
    }
 
    echo json_encode($users_arr["users"]);
}
else{
    echo json_encode(array());
}
?>