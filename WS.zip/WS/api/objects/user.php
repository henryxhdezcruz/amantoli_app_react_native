<?php
class User{
 
    private $conn;
    private $table_name = "users";
 
    public $id;
    public $name;
    public $lastname;
    public $email;
    public $password;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function read(){
    
        $query = "SELECT
                    `id`, `name`, `email`, `password`
                FROM
                    " . $this->table_name . " 
                ORDER BY
                    id DESC";
    
        $stmt = $this->conn->prepare($query);
    
        $stmt->execute();
    
        return $stmt;
    }

    function read_single(){
    
        $query = "SELECT * FROM users where id= '".$this->id."'";
    
        $stmt = $this->conn->prepare($query);
    
        $stmt->execute();
    
        return $stmt;
    }

    function readPassword(){

        $query = "SELECT
                   `password`
                FROM
                    " . $this->table_name . " 
                WHERE
                    email= '".$this->email."'";

        $pwd = $this->conn->prepare($query);

        $pwd->execute();

        $row = $pwd->fetch(PDO::FETCH_ASSOC);

        $return = $row['password'];

        return $return;

    }


    function login(){

        $pwd = $this->readPassword();

        if (password_verify($this->password, $pwd)) {

            $query = "SELECT
                    `id`, `name`, `email`, `password`, `email_verified_at`
                FROM
                    " . $this->table_name . " 
                WHERE
                    email= '".$this->email."'";
    
            $stmt = $this->conn->prepare($query);
        
            $stmt->execute();

        } else {
            echo 'La contraseña no es válida.';
        }
        
        return $stmt;
    }

    function create(){
    
        if($this->isAlreadyExist()){
            return false;
        }
        
        $query = "INSERT INTO  ". $this->table_name ." 
                        (`name`, `email`, `password`)
                  VALUES
                        ('".$this->name."', '".$this->email."', '".$this->password."')";
    
        $stmt = $this->conn->prepare($query);
    
        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }

        return false;
    }

    function update(){
    
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    name='".$this->name."', email='".$this->email."', password='".$this->password."'
                WHERE
                    id='".$this->id."'";
    
        $stmt = $this->conn->prepare($query);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function update_email(){
    
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    email='".$this->email."'
                WHERE
                    id='".$this->id."'";
    
        $stmt = $this->conn->prepare($query);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function update_password(){
    
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    password='".$this->password."'
                WHERE
                    id='".$this->id."'";
    
        $stmt = $this->conn->prepare($query);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function update_name(){
    
        $query = "UPDATE
                    " . $this->table_name . "
                SET
                    name='".$this->name."' , last_name='".$this->last_name."'
                WHERE
                    id='".$this->id."'";
    
        $stmt = $this->conn->prepare($query);
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function delete(){
        
        $query = "DELETE FROM
                    " . $this->table_name . "
                WHERE
                    id= '".$this->id."'";
        
        $stmt = $this->conn->prepare($query);
        
        if($stmt->execute()){
            return true;
        }
        return false;
    }

    function isAlreadyExist(){
        $query = "SELECT *
            FROM
                " . $this->table_name . " 
            WHERE
                email='".$this->email."'";

        $stmt = $this->conn->prepare($query);

        $stmt->execute();

        if($stmt->rowCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }
}