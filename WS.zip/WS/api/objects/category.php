<?php
class Category{
 
    private $conn;
    
    public $category_name;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function read_only_category(){
        $query = "SELECT * from GetProducts where category_name = '".$this->category_name."' order by product_id desc";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function category_image(){
        $query = "SELECT * from categories where name = '".$this->category_name."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read(){
        $query = "SELECT * from categories";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}