<?php
class Directions{
 
    private $conn;
    private $table_name = "directions";

    public $name;
    public $state_id;
    public $city_id;
    public $colony_id;
    public $references;

    public function __construct($db){
        $this->conn = $db;
    }

    function addAddress(){
        
        $query = "INSERT INTO  ". $this->table_name ." 
                        (`name`, `state_id`, `city_id`, `colony_id`, `references`)
                  VALUES
                        ('".$this->name."', '".$this->state_id."', '".$this->city_id."', '".$this->colony_id."', '".$this->references."')";
    
        $stmt = $this->conn->prepare($query);
    
        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }
        return false;
    }

    function getAddresss(){
        $query = "SELECT
                    `*`
                FROM
                    GetDirections
                WHERE
                    user_id= '".$this->user_id."'";
    
        $stmt = $this->conn->prepare($query);
    
        $stmt->execute();
        return $stmt;
    }

    function deleteAddresss(){
        $query = "DELETE FROM
                    " . $this->table_name . "
                WHERE
                    product_id= '".$this->product_id."'";
        
        $stmt = $this->conn->prepare($query);
        
        if($stmt->execute()){
            return true;
        }
        return false;
    }
}