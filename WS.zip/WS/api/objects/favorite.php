<?php
class Favorite{
 
    private $conn;
    private $table_name = "favorite_products";

    public $product_id;
    public $user_id;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function addFavorite(){
        
        $query = "INSERT INTO  ". $this->table_name ." 
                        (`product_id`, `user_id`)
                  VALUES
                        ('".$this->product_id."', '".$this->user_id."')";
    
        $stmt = $this->conn->prepare($query);
    
        if($stmt->execute()){
            $this->id = $this->conn->lastInsertId();
            return true;
        }

        return false;
    }


    function isFavorite(){
        $query = "SELECT *
            FROM
                " . $this->table_name . " 
            WHERE
                user_id='".$this->user_id."' and product_id='".$this->product_id."'";

        $stmt = $this->conn->prepare($query);

        $stmt->execute();

        if($stmt->rowCount() > 0){
            return true;
        }
        else{
            return false;
        }
    }

    function getFavorites(){
        $query = "SELECT
                    `*`
                FROM
                    GetProductFavorites 
                WHERE
                    user_id= '".$this->user_id."'";
    
        $stmt = $this->conn->prepare($query);
    
        $stmt->execute();
        return $stmt;
    }

    function deleteFavorites(){
        $query = "DELETE FROM
                    " . $this->table_name . "
                WHERE
                    product_id= '".$this->product_id."'";
        
        $stmt = $this->conn->prepare($query);
        
        if($stmt->execute()){
            return true;
        }
        return false;
    }
}