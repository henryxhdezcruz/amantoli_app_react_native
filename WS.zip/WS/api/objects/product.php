<?php
class Product{
 
    private $conn;
    private $table_name = "products";
    
    public $id;
    public $imageable_id;
    public $size_id;
    public $category_name;
    public $search;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function read(){
        $query = "SELECT * from GetProducts order by id desc limit 10";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function search(){
        $query = "SELECT * from GetProducts where product_name LIKE '%".$this->search."%' OR product_description LIKE '%".$this->search."%' OR category_name LIKE '%".$this->search."%' OR brand_name LIKE '%".$this->search."%'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_single(){
        $query = "SELECT * from GetProducts where product_id = '".$this->id."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_products_for_category(){
        $query = "SELECT * from GetProducts where category_name = '".$this->category_name."' order by product_id desc limit 4";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_image_product(){
        $query = "SELECT * from images where imageable_id = '".$this->imageable_id."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_color_product(){
        $query = "SELECT * from GetColorsProduct where product_id = '".$this->id."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_size_product(){
        $query = "SELECT * from sizes where product_id = '".$this->id."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    function read_color_size_product(){
        $query = "SELECT * from GetColorsSize where size_id = '".$this->size_id."'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}