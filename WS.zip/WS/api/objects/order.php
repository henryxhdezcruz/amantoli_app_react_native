<?php
class Order{
 
    private $conn;
    
    public $user_id;
 
    public function __construct($db){
        $this->conn = $db;
    }

    function read_single_order(){
        $query = "SELECT * from orders where user_id = '".$this->user_id."' order by created_at desc";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}